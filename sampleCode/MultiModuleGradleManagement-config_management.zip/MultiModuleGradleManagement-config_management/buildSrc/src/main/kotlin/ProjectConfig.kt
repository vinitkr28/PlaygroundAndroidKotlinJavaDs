object ProjectConfig {
    const val appId = "com.plcoding.multimodulegradlemanagement"
    const val minSdk = 24
    const val compileSdk = 33
    const val targetSdk = 33
    const val versionCode = 1
    const val versionName = "1.0"
}