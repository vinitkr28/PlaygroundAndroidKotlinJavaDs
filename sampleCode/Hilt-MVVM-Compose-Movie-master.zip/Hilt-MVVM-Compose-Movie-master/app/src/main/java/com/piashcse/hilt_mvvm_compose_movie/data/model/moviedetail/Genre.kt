package com.piashcse.hilt_mvvm_compose_movie.data.model.moviedetail

data class Genre(
    val id: Int?,
    val name: String
)