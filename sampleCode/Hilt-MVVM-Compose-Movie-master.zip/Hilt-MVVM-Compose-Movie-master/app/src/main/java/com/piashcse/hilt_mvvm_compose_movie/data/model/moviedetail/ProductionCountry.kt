package com.piashcse.hilt_mvvm_compose_movie.data.model.moviedetail

data class ProductionCountry(
    val iso_3166_1: String,
    val name: String
)