package com.piashcse.hilt_mvvm_compose_movie.data.model.moviedetail

data class SpokenLanguage(
    val english_name: String,
    val iso_639_1: String,
    val name: String
)