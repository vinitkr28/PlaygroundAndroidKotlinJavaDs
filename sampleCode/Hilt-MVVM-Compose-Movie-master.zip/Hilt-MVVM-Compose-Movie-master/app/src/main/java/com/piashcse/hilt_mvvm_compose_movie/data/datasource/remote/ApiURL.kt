package com.piashcse.hilt_mvvm_compose_movie.data.datasource.remote

object ApiURL {
    const val API_KEY = "59cd6896d8432f9c69aed9b86b9c2931"
    const val BASE_URL = "https://api.themoviedb.org/3/"
    const val IMAGE_URL = "https://image.tmdb.org/t/p/w342"
}