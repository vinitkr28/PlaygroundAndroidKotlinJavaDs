package com.piashcse.hilt_mvvm_compose_movie.data.model

import com.piashcse.hilt_mvvm_compose_movie.data.model.moviedetail.Genre

data class Genres(val genres: List<Genre>)