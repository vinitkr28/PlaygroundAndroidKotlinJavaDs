package com.piashcse.hilt_mvvm_compose_movie.data.model

data class GenreId(val genreId: String? = null)