package com.piashcse.hilt_mvvm_compose_movie.data.model.moviedetail

data class BelongsToCollection(
    val backdrop_path: String,
    val id: Int,
    val name: String,
    val poster_path: String
)