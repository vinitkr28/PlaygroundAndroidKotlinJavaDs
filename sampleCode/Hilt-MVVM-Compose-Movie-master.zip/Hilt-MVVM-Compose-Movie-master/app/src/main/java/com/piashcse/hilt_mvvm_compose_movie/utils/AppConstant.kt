package com.piashcse.hilt_mvvm_compose_movie.utils

object AppConstant {
    const val MINIMIZED_MAX_LINES = 2
    const val DEFAULT_GENRE_ITEM = "All"
}